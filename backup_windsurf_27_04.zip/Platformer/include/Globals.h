#pragma once
#include "map.h"
#include "camera.h"
#include "player.h"

#include <SFML/Graphics.hpp>
#include <iostream>

using namespace std;
using namespace sf;

struct O {
    float width{};
    float height{};
};

inline float cellSizeF = 60.f;
inline unsigned int cellSizeU = 60;
inline O window;
inline string windowMode = "FullScreen";
inline string dataPath = "/home/niki/Progr/Games/Platformer/data/";

inline RenderWindow* pwindow;
inline Clock* pclock;
inline Map* pmap;
inline Camera* pcamera;
inline Player* pplayer;