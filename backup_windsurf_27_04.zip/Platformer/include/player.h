#pragma once

#include "eventSystem.h"
#include "weapon.h"
//#include "Globals.h"

#include <SFML/Graphics.hpp>
#include <iostream>


using namespace std;
using namespace sf;

class Player : public IEventHandler {
public:
    Player();

    void update(float dt);

    void render();

    void renderUI();

    void EventHandler(const ::Event& e) override;

    int getX();
    int getY();

    int getWidth();
    int getHeight();

    bool getIsAttack();
    Sword getWeapon();

    bool getIsInvincible();

    void setSword(string PathToTexture, string Name, Vector2f Size, float AttackSpeed, float Damage);

private:
    float x{0}, y{0}, Vx{}, Vy{};
    //float width = 34 * 1.75, height = 59 * 1.75;
    float width = 0, height = 0;
    string direction = "right";
    float moveSpeed = 0.5;
    float jumpForce = 1.3;
    float animationSpeed = 0.0075;
    float animationFrame{};
    float gravity = 0.003;
    bool inTheAir = false;
    bool isVisible = true;
    Sprite sprite;
    Texture texture;

    int hp = 10;
    Sprite heartSprite;
    Texture heartTexture;
    Vector2f heartSize{ 30, 30 };
    Vector2f healthbarPos{};
    float heartGap = 2;

    float timeStep = 0.005;

    bool isInvincible = false;
    float invincDuration = 1.5;
    float invincTimer{};
    float invincBlinkDuration = 0.17;        // Duration of 1 blink during invinc.
    float blinkStopClock{};                 // used for countdown for each blink 

    bool isStunned = false;
    float stunDuration = 1;
    float stunTimer{};

    Sword sword;

    bool isAttack = false;
    float swordAttackAngle{};
    

    void restrictions(float dt);

    void movement(float dt);

    void jump(float force);

    void renderHealthbar();

    void updateAttack();

};

