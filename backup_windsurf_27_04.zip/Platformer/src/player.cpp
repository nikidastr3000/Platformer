#include "player.h"

#include "Globals.h"
#include "weapon.h"

#include <SFML/Graphics.hpp>
#include <iostream>
#include <cmath>

using namespace std;
using namespace sf;

// Public
Player::Player(): sprite(texture), heartSprite(heartTexture){
    width = cellSizeF * 0.6;
    height = cellSizeF * 1.8;

    if (!texture.loadFromFile(dataPath + "Textures/player.png")) {
        cout << "Error with loading player texture" << endl;
    }

    sprite.setPosition(Vector2f(x, y));
    sprite.setTexture(texture, true);
    sprite.setTextureRect(IntRect({ 0, 0 }, { 33, 58 }));

    Vector2i originalSize = sprite.getTextureRect().size;
    sprite.setScale({ width / originalSize.x, height / originalSize.y });

    if (!heartTexture.loadFromFile(dataPath + "Textures/heart.png")) {
        cout << "Error with loading heart texture" << endl;
    }

    healthbarPos = { window.width / 2 - 300, window.height - 130 };
    heartSprite.setTexture(heartTexture, true);

    originalSize = heartSprite.getTextureRect().size;
    heartSprite.setScale({ heartSize.x / originalSize.x, heartSize.y / originalSize.y });
}

void Player::update(float dt) {
    // movement
    if(!isStunned)
        movement(dt);

    if (inTheAir)
        Vy += gravity * dt;

    restrictions(dt);

    //move camera with sprite if necessary
    if ((x + Vx > pcamera->view.getCenter().x && Vx > 0) || (x + Vx < pcamera->view.getCenter().x && Vx < 0)) {
        pcamera->view.move({ Vx * dt, 0.f });
    }
    //move sprite
    x += Vx * dt;
    y += Vy * dt;
    Vx = 0;
    sprite.setPosition(Vector2f(x, y));

    // render healthbar, ...
    renderUI();

    // 
    if (!isInvincible)
        updateAttack();

    //timers
    if (invincTimer > 0.f) {
        invincTimer -= timeStep;
        if (blinkStopClock - invincTimer >= invincBlinkDuration) {
            blinkStopClock = invincTimer;
            isVisible = isVisible ? false : true;
        }


    }
    else if (isInvincible) {
        isInvincible = false;
        isVisible = true;
    }
        

    if (stunTimer > 0.f) {
        stunTimer -= timeStep * dt;
    }
    else if (isStunned)
        isStunned = false;
}

void Player::render() {
    if (!isVisible)
        return;

    pwindow->draw(sprite);

    if (isAttack) {
        pwindow->draw(sword.sprite);
    }
}

void Player::renderUI() {

    renderHealthbar();

}

void Player::EventHandler(const ::Event& e)
{
    switch (e.eventType)
    {
    case EventType::COLLISION:
        if (!isInvincible) {
            Vx = e.direction.x * 20;
            Vy = -0.5;

            hp -= 1;

            isInvincible = true;
            invincTimer = invincDuration;
            blinkStopClock = invincDuration;

            isStunned = true;
            stunTimer = stunDuration;

            isAttack = false;

        }
        break;
    }
}

int Player::getX() { return x; }
int Player::getY() { return y; }

int Player::getWidth() { return width; }
int Player::getHeight() { return height; }

bool Player::getIsAttack() { return isAttack; }
Sword Player::getWeapon() { return sword; }

bool Player::getIsInvincible() { return isInvincible; }

void Player::setSword(string PathToTexture, string Name, Vector2f Size, float AttackSpeed, float Damage) {
    sword.init(PathToTexture, Name, Size, AttackSpeed, Damage);
}

// Private
void Player::restrictions(float dt) {
    // if sprite above the screen       (not good)
    if (y + Vy * dt < 0) {
        return;
    }

    // real grid_pos of sprite now
    int left_r = static_cast<int>((x - pmap->topleft.x) / cellSizeF);
    int right_r = static_cast<int>((x + sprite.getGlobalBounds().size.x - pmap->topleft.x) / cellSizeF);
    int up_r = static_cast<int>((y - pmap->topleft.y) / cellSizeF);
    int down_r = static_cast<int>((y + sprite.getGlobalBounds().size.y - pmap->topleft.y) / cellSizeF);

    // virtual grid_pos of sprite if + Vx/Vy
    int left_v = static_cast<int>(((x + Vx * dt) - pmap->topleft.x) / cellSizeF);
    int right_v = static_cast<int>(((x + Vx * dt) + sprite.getGlobalBounds().size.x - pmap->topleft.x) / cellSizeF);
    int up_v = static_cast<int>(((y + Vy * dt) - pmap->topleft.y) / cellSizeF);
    int down_v = static_cast<int>(((y + Vy * dt) + sprite.getGlobalBounds().size.y - pmap->topleft.y) / cellSizeF);

    // inTheAir check
    bool isBlockDown = false;
    for (int i = left_r; i <= right_r; i++) {
        if (pmap->array[i][down_r + 1])
            isBlockDown = true;
    }

    if (!inTheAir) {
        if (static_cast<int>(y + sprite.getGlobalBounds().size.y + 1 - pmap->topleft.y) % static_cast<int>(cellSizeF) != 0) {
            inTheAir = true;
        }
        else if (!isBlockDown) {
            inTheAir = true;
        }
    }

    // right side collision check
    if (Vx > 0) {
        if (right_v >= pmap->getWidth()) {  // right map border
            x = pmap->topleft.x + (right_r + 1) * cellSizeF - sprite.getGlobalBounds().size.x - 1;
            Vx = 0;
        }
        else
            if (right_v > right_r) {    // if sprite steps on new block
                bool blockRight = false;
                for (int i = up_r; i <= down_r; i++) {
                    if (pmap->array[right_v][i])
                        blockRight = true;
                }

                if (blockRight) {
                    x = pmap->topleft.x + (right_r + 1) * cellSizeF - sprite.getGlobalBounds().size.x - 1;
                    Vx = 0;
                }
            }
    }

    // left side collision check
    if (Vx < 0) {
        if (x + Vx * dt < 0) {  // left map border
            x = 0;
            Vx = 0;
        }
        else
            if (left_v < left_r) {  // if sprite steps on new block
                bool blockLeft = false;
                for (int i = up_r; i <= down_r; i++) {
                    if (pmap->array[left_v][i])
                        blockLeft = true;
                }

                if (blockLeft) {
                    x = pmap->topleft.x + (left_v + 1) * cellSizeF + 1;
                    Vx = 0;
                }
            }
    }

    // above collision check
    if (Vy > 0) {
        if (down_v > down_r) {  // if sprite steps on new block
            bool isBlockDown = false;
            for (int i = left_r; i <= right_r; i++) {
                if (pmap->array[i][down_v])
                    isBlockDown = true;
            }

            if (isBlockDown) {
                y = pmap->topleft.y + (down_r + 1) * cellSizeF - sprite.getGlobalBounds().size.y - 1;
                Vy = 0;
                inTheAir = false;

                //pcamera->stabilizationByY(y - pcamera->view.getCenter().y);
            }
        }
    }

    // under collision check
    if (Vy < 0) {
        if (up_v < up_r) {  // if sprite steps on new block
            bool blockUp = false;
            for (int i = left_r; i <= right_r; i++) {
                if (pmap->array[i][up_v])
                    blockUp = true;
            }

            if (blockUp) {
                y = pmap->topleft.y + (up_v + 1) * cellSizeF + 1;
                Vy = 0.3;
            }
        }
    }
}

void Player::movement(float dt) {
    int dir = 0;

    if (Keyboard::isKeyPressed(Keyboard::Scancode::D) || Keyboard::isKeyPressed(Keyboard::Scancode::Right)) {
        dir = 1;
    }
    if (Keyboard::isKeyPressed(Keyboard::Scancode::A) || Keyboard::isKeyPressed(Keyboard::Scancode::Left)) {
        if (dir == 1)
            dir = 0;
        else
            dir = -1;
    }
    if (dir == 1) {
        Vx = moveSpeed;
        animationFrame += animationSpeed * dt;
        direction = "right";
        if (animationFrame > 2) animationFrame -= 2;
        sprite.setTextureRect(IntRect({ 34 * int(animationFrame), 0 }, { 33, 58 }));
    }
    else if (dir == -1) {
        Vx = -moveSpeed;
        animationFrame += animationSpeed * dt;
        direction = "left";
        if (animationFrame > 2) animationFrame -= 2;
        sprite.setTextureRect(IntRect({ 34 * int(animationFrame), 59 }, { 33, 58 }));
    }

    if (Keyboard::isKeyPressed(Keyboard::Scancode::Space)) {
        jump(jumpForce);
    }
}

void Player::jump(float force) {
    if (!inTheAir) {
        //inTheAir = true;
        Vy = -force;
    }
}

void Player::renderHealthbar() {
    float x = healthbarPos.x;
    float y = healthbarPos.y;
    for (int i = 0; i < hp; i++) {
        x += heartGap;
        heartSprite.setPosition({x, y});
        pwindow->draw(heartSprite);
        x += heartSize.x;
    }

}

void Player::updateAttack() {
    if (Mouse::isButtonPressed(Mouse::Button::Left)) {
        // if its begin of attack
        if (!isAttack) {
            // finding angle between player's center and mousecursor
            Vector2f globalPlayerCenter = sprite.getGlobalBounds().getCenter();        // global(world) position(center)
            Vector2i playerCenter = pwindow->mapCoordsToPixel(globalPlayerCenter, pcamera->view);
            Vector2i mousePos = Mouse::getPosition(*pwindow);

            float dx = mousePos.x - playerCenter.x;
            float dy = playerCenter.y - mousePos.y;
            float angleRad = atan2(dx, dy);
            float angleDeg = angleRad * (180.0f / 3.141592653589793);
            if (angleDeg < 0.0f)
                angleDeg += 360.0f;  // ������� � [0, 360)

            swordAttackAngle = (direction == "right") ? angleDeg - 50.f : angleDeg + 50.f;     //������� ����� ���� ���� ����� ��� ����� �����
            sword.sprite.setRotation(degrees(swordAttackAngle));
        }

        isAttack = true;
    }
    else {
        // if its end of attack
        if (isAttack) {
            swordAttackAngle = 0;
        }

        isAttack = false;
    }

    if (isAttack) {
        sword.sprite.setPosition({x + width / 2, y + height / 2});
        if (direction == "right")
            sword.sprite.rotate(degrees(sword.attackSpeed));
        else if (direction == "left")
            sword.sprite.rotate(-degrees(sword.attackSpeed));
    }

}




////////////////Sword///////////////////////
